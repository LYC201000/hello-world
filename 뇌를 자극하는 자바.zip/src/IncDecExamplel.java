
public class IncDecExamplel {
	public static void main(String args[]) {
		int num1=10,num2=10,num3=10,num4=10;
		int result1=num1++; //++연산의 결과는 num1의기존값
		int result2=num2--; //--연산의 결과는 num2의기존값
		int result3=++num3; //++연산의 결과는 num3의새로운값
		int result4=--num4; //--연산의 결과는 num4의새로운값
		System.out.println("result1="+result1);
		System.out.println("result2="+result2);
		System.out.println("result3="+result3);
		System.out.println("result4="+result4);
		
	}

}

