/**
 * 2018. 5. 1. dev By lee.Y.C
   
   Variable2.java
 */

/**
 * @author Administrator
 *
 */
public class Variable2 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int number1=30, number2=120;
		int total=plus(number1,number2);
		System.out.println("total:"+total);
	}
	static int plus(int a,int b) 
	{
		return a+b;
	}

}
