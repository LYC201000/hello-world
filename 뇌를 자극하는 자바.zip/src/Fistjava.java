/**
 * 2018. 4. 30. dev By lee.Y.C
   
   Fistjava.java
 */

/**
 * @author Administrator
 *
 */
public class Fistjava {
	public static void main(String[] args) {
		
		System.out.println("Hello world! with command");
		
		
		
		int number = Math.abs(-15);
		System.out.printf("절대값:%d\n",number);

		
		
	}
   
	
}
