/**
 * 2018. 5. 1. dev By lee.Y.C
   
   ConditionlOpExampel.java
 */

public class ConditionlOpExampel {

	public static void main(String[] args) {

		int a=20,b=30, max;
		max	=	a	<	b	?	a:b;
		System.out.println(max);
	}

}
